const allowedOrigins = [
    'http://localhost:3000',
    'https://resellersprint.com',
    'https://www.cotektechnologies.com',
    'https://cotektech.com',
    'https://resprint.api.resellersprint.com',
    'http://localhost:3500'
]

module.exports = allowedOrigins;