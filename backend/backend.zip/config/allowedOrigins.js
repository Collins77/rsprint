const allowedOrigins = [
    'http://localhost:3000',
    'https://resellersprint.com',
    'https://www.cotektechnologies.com',
    'https://cotektech.com'
]

module.exports = allowedOrigins;