const express = require('express');
const router = express.Router();
const resellersController = require('../controllers/resellersController');
const auth = require('../middleware/auth');

// router.route('/get-resellers').get(resellersController.getAllResellers)
// router.route('/get-reseller/:id').get(resellersController.getReseller)
// router.route('/signup').post(resellersController.createNewReseller)
// router.route('/login').post(resellersController.loginReseller)
// router.route('/logout').get(resellersController.logOutReseller)
// router.route('/edit-account').patch(resellersController.updateReseller)
// router.route('/delete-reseller').delete(resellersController.deleteReseller)
// router.route('/approve-reseller/:id',isAuthenticated).patch(resellersController.approveReseller)
//     .patch(resellersController.updateReseller)
//     .delete(resellersController.deleteReseller)
router.get('/get-resellers', auth, resellersController.getAllResellers);
router.get('/get-reseller',  resellersController.getReseller);
router.get('/logged-in', resellersController.loggedIn);
router.post('/signup', resellersController.createNewReseller);
router.post('/login', resellersController.loginReseller);
router.get('/logout', resellersController.logOutReseller);
router.patch('/edit-account',auth, resellersController.updateReseller);
router.delete('/delete-reseller', auth, resellersController.deleteReseller);
router.patch('/approve-reseller/:id', auth, resellersController.approveReseller);
router.patch('/update-reseller/:id', auth, resellersController.updateReseller);
router.delete('/delete-reseller/:id', auth, resellersController.deleteReseller);

module.exports = router;